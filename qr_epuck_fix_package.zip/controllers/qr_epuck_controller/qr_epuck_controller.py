from controller import Robot
import math
import os

try:
    import cv2
    import numpy as np
except Exception as exc:
    raise RuntimeError(
        "OpenCV vagy NumPy nem érhető el a Webots Python környezetben. "
        "Telepítsd a cv2 és numpy csomagokat ahhoz a Pythonhoz, amit a Webots használ."
    ) from exc

TIME_STEP = 64
MAX_SPEED = 6.28
SEARCH_SPEED = 1.6
FORWARD_SPEED = 3.0
TURN_SPEED = 2.2
AVOID_THRESHOLD = 80.0
EXECUTION_STEPS = 18  # ~1.1 s 64 ms timestep mellett

robot = Robot()

left_motor = robot.getDevice('left wheel motor')
right_motor = robot.getDevice('right wheel motor')
left_motor.setPosition(float('inf'))
right_motor.setPosition(float('inf'))
left_motor.setVelocity(0.0)
right_motor.setVelocity(0.0)

camera = robot.getDevice('camera')
camera.enable(TIME_STEP)
# Nem használjuk a Webots saját Recognition funkcióját,
# mert itt az OpenCV-s QR-felismerés dolgozik.

ps_names = ['ps0', 'ps1', 'ps2', 'ps3', 'ps4', 'ps5', 'ps6', 'ps7']
ps = []
for name in ps_names:
    sensor = robot.getDevice(name)
    sensor.enable(TIME_STEP)
    ps.append(sensor)

qr = cv2.QRCodeDetector()

state = 'SEARCH'
last_command = None
cooldown_steps = 0
execute_steps_left = 0
current_command = None

def clamp_speed(value):
    return max(-MAX_SPEED, min(MAX_SPEED, value))

def set_speed(left, right):
    left_motor.setVelocity(clamp_speed(left))
    right_motor.setVelocity(clamp_speed(right))

def read_frame():
    width = camera.getWidth()
    height = camera.getHeight()
    raw = camera.getImage()
    if raw is None:
        return None
    frame = np.frombuffer(raw, dtype=np.uint8).reshape((height, width, 4))

    # A Webots kamera 4 csatornás képet ad; az alpha csatorna eldobható.
    # A csatornasorrend verziótól/platformtól függhet, ezért mindkét gyakori
    # értelmezést kipróbáljuk, és amelyikből érvényes QR szöveg jön, azt használjuk.
    bgr = frame[:, :, :3]
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGRA2RGB)
    return bgr, rgb

def detect_qr():
    frames = read_frame()
    if frames is None:
        return "", None, None

    candidates = []
    for image in frames:
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) if image.shape[2] == 3 else image
        text, points, _ = qr.detectAndDecode(gray)
        candidates.append((text, points, image))

    for text, points, image in candidates:
        if text:
            return text.strip(), points, image

    return "", None, frames[0]

def normalize_command(text):
    t = text.strip().lower()
    mapping = {
        'bal': 'bal',
        'left': 'bal',
        'jobb': 'jobb',
        'right': 'jobb',
        'stop': 'allj',
        'állj': 'allj',
        'allj': 'allj',
        'elore': 'elore',
        'előre': 'elore',
        'forward': 'elore',
        'continue': 'elore',
        'folytatás': 'elore',
        'folytatas': 'elore',
    }
    return mapping.get(t)

def qr_center_x(points):
    if points is None:
        return None
    pts = np.array(points).reshape(-1, 2)
    return float(np.mean(pts[:, 0]))

def obstacle_state():
    values = [s.getValue() for s in ps]
    right_obstacle = values[0] > AVOID_THRESHOLD or values[1] > AVOID_THRESHOLD or values[2] > AVOID_THRESHOLD
    left_obstacle = values[5] > AVOID_THRESHOLD or values[6] > AVOID_THRESHOLD or values[7] > AVOID_THRESHOLD
    front_obstacle = values[7] > AVOID_THRESHOLD or values[0] > AVOID_THRESHOLD or values[1] > AVOID_THRESHOLD or values[6] > AVOID_THRESHOLD
    return left_obstacle, right_obstacle, front_obstacle, values

def start_execute(command):
    global state, current_command, execute_steps_left, cooldown_steps, last_command
    state = 'EXECUTE'
    current_command = command
    execute_steps_left = EXECUTION_STEPS
    cooldown_steps = 25
    last_command = command
    print(f"QR parancs: {command}")

while robot.step(TIME_STEP) != -1:
    left_obs, right_obs, front_obs, values = obstacle_state()

    if front_obs:
        # Egyszerű elsőbbségi akadályelkerülés
        if left_obs and not right_obs:
            set_speed(TURN_SPEED, -TURN_SPEED)
        else:
            set_speed(-TURN_SPEED, TURN_SPEED)
        continue

    if cooldown_steps > 0:
        cooldown_steps -= 1

    if state == 'EXECUTE':
        if current_command == 'bal':
            set_speed(-TURN_SPEED, TURN_SPEED)
        elif current_command == 'jobb':
            set_speed(TURN_SPEED, -TURN_SPEED)
        elif current_command == 'allj':
            set_speed(0.0, 0.0)
        elif current_command == 'elore':
            set_speed(FORWARD_SPEED, FORWARD_SPEED)
        else:
            set_speed(0.0, 0.0)

        execute_steps_left -= 1
        if execute_steps_left <= 0:
            state = 'SEARCH'
            current_command = None
        continue

    raw_text, points, image = detect_qr()
    cmd = normalize_command(raw_text) if raw_text else None

    if cmd and cooldown_steps == 0:
        center_x = qr_center_x(points)
        width = camera.getWidth()
        error = 0.0 if center_x is None else (center_x - width / 2.0)

        if abs(error) > width * 0.10:
            # Középre forgatás, mielőtt végrehajtjuk a parancsot
            gain = 0.015
            turn = max(-2.0, min(2.0, gain * error))
            set_speed(turn, -turn)
        else:
            start_execute(cmd)
    else:
        # SEARCH
        set_speed(SEARCH_SPEED, -SEARCH_SPEED)
